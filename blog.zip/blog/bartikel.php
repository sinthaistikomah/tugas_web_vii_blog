<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<!--untuk mengaktifkan responsive design-->
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<title>Buat artikel</title>
	<!--panggil file css bootstrapp-->
  <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
  	<link rel="stylesheet" href="__Bootstrap/css/bootstrap.css">
</head>

<body>

	<div class="jumbotron text-center" style="margin-bottom:0">
  		<img src="logo.png" width="300px">
	</div>

	<nav class="navbar navbar-expand-sm bg-info navbar-dark">
  	<ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="utama.php">Beranda</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="lifestyle.php">Lifestyle</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="kesehatan.php">Kesehatan</a>
    </li>
    <li class="nav-item active">
    	<a class="nav-link" href="kuliner.php">Kuliner</a>
    </li>
    <li class="nav-item">
    	<a class="nav-link" href="profil.php">Profil</a>
    </li>
    <li class="nav-item">
    	<a class="nav-link" href="bartikel.php">Buat Artikel</a>
    </li>
    <li class="nav-item">
    	<a class="nav-link" href="index.php">Logout</a>
    </li>
  </ul>
</nav>
<div class="kotak">
		<h1>
			Buat Artikel<br/>
				</h1>
        <div class="row">
          <div class="col-sm-8 col-sm-offset-2">
           <form>
             <div class="form-group">
               <label for="nama">Judul </label>
               <input type="text" id="nama" class="form-control" placeholder="masukkan judul">
             </div>
             
		<textarea class="ckeditor" id="ckedtor"></textarea>
		<br/>
		<button class="tombol">Simpan</button>
	</div>

</body>
</html>
