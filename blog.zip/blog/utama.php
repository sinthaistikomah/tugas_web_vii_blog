<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<!--untuk mengaktifkan responsive design-->
	<meta name="viewport" content="width-device-width, initial-scale=1">
	<title>Dream Land</title>
	<!--panggil file css bootstrapp-->
	<link rel="stylesheet" href="__Bootstrap/css/bootstrap.css">
</head>

<body>

	<div class="jumbotron text-center" style="margin-bottom:0">
  		<img src="logo.png" width="300px">
	</div>

	<nav class="navbar navbar-expand-sm bg-info navbar-dark">
  	<ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-link" href="index.php">Beranda</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="lifestyle.php">Lifestyle</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="kesehatan.php">Kesehatan</a>
    </li>
    <li class="nav-item">
    	<a class="nav-link" href="kuliner.php">Kuliner</a>
    </li>
    <li class="nav-item">
    	<a class="nav-link" href="profil.php">Profil</a>
    </li>
    <li class="nav-item">
    	<a class="nav-link" href="#">Buat Artikel</a>
    </li>
    <li class="nav-item">
    	<a class="nav-link" href="login.php">Logout</a>
    </li>
  </ul>
</nav>
<br>
<div class="container" style="margin-left: 0">
	<div class="row">
		<div class="col-md-3">
			<div class="jumbotron">
				<h2 align="center">TOP ARTIKEL</h2>
				<h2 align="center">-----------</h2>
				<h4 align="center">Special Ramadhan!</h4>
			</div>

		</div>
		<div class="col-md-3 text-center">
				<img src="resep_tahu_tauge.jpg" class="img-thumbnail" width="280px">
				<br>
				<h5>Resep Tahu Tauge </h5>
				<h5>Sehat Menggugah Selera</h5>
				<a href="artikelkuliner.php">
	  		<button type="button" class="btn btn-primary btn-sm">Baca Artikel>>></button>
					</a>
		</div>
		<div class="col-md-3 text-center">
			<img src="resep_jelly.jpg" class="img-thumbnail" width="280px">
			<br>
			<h5>Kue Lebaran</h5>
			<h5>Jelly agar agar Praktis!</h5>
			<button type="button" class="btn btn-primary btn-sm">Baca Artikel>>></button>
		</div>
		<div class="col-md-3 text-center">
			<img src="lips.jpg" class="img-thumbnail" width="280px">
			<br>
			<h5>Mengatasi Bibir</h5>
			<h5>Kering Saat Ramadhan</h5>
			<button type="button" class="btn btn-primary btn-sm">Baca Artikel>>></button>
		</div>

	</div>

</div>




</body>
</html>
