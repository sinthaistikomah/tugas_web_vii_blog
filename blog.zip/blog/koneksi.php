<?php
   $hostname  = "localhost";
   $username  = "root";
   $password  = "";
   $dbname  = "tugas";
   $db = new mysqli($hostname, $username, $password, $dbname);
?>
