</html><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <!--untuk mengaktifkan responsive design-->
  <meta name="viewport" content="width-device-width, initial-scale=1">
  <title>Kesehatan</title>
  <!--panggil file css bootstrapp-->
  <link rel="stylesheet" href="__Bootstrap/css/bootstrap.css">
</head>

<body>

  <div class="jumbotron text-center" style="margin-bottom:0">
      <img src="logo.png" width="300px">
  </div>

  <nav class="navbar navbar-expand-sm bg-info navbar-dark">
    <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="utama.php">Beranda</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="lifestyle.php">Lifestyle</a>
    </li>
    <li class="nav-item active">
      <a class="nav-link" href="kesehatan.php">Kesehatan</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="kuliner.php">Kuliner</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="profil.php">Profil</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="bartikel.php">Buat Artikel</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="login.php">Logout</a>
    </li>
  </ul>
</nav>

<div class="container text-center" >
  <div class="row">
    <div class="col-md-4 text-center">
    <br>
      <img src="obesitas.jpg" class="img-thumbnail" width="300px">
      <br>
      <h5><strong>Waspada!! Obesitas</strong></h5>
      <h5><strong>Incar Perempuan Indonesia</strong></h5>
      <a href="artikel_obesitas.html">
      <button type="button" class="btn btn-primary btn-sm">
        Baca Artikel>>>
      </button></a>
    </div>
    <div class="col-md-4 text-center">
    <br>
      <img src="kesehatan1.jpg" class="img-thumbnail" width="300px">
      <br>
      <h5><strong>Ini dia! Masalah Kesehatan Yang</strong></h5>
      <h5><strong>Sering Mengintai Generasi Milenial</strong></h5>
      <button type="button" class="btn btn-primary btn-sm">Baca Artikel>>></button>
    </div>
    <div class="col-md-4 text-center">
    <br>
      <img src="kesehatan2.jpg" class="img-thumbnail" width="300px">
      <br>
      <h5><strong>4 Cara agar tidak</strong></h5>
      <h5><strong>gampang lemas saat puasa</strong></h5>
      <button type="button" class="btn btn-primary btn-sm">Baca Artikel>>></button>
    </div>
  </div>
</div>

<div class="container text-center">
  <div class="row">
    <div class="col-md-4 text-center">
    <br>
      <img src="kesehatan3.jpg" class="img-thumbnail" width="300px">
      <br>
      <h5><strong>5 Cara Tak Biasa</strong></h5>
      <h5><strong>Mengatasi Sulit BAB</strong></h5>
      <button type="button" class="btn btn-primary btn-sm">Baca Artikel>>></button>
    </div>
  </div>

</div>


</body>
</html>
