<?php
   session_start();
   if(isset($_SESSION['username'])) {
   header('location:index.php'); }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Form Pendaftaran</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
  <body >
    <div class="col-md-4 col-md-offset-4 form-login">

  <form action="cek_daftar.php" class="inner-login" method="post">
    <h1 class="text-center title-login">Daftar Baru</h1>
  <div class="form-group">
  <label>Username</label>
  <input type="text" class="form-control" name="username" placeholder="Username">
</div>
<div class="form-group">
<label>Password</label>
<input type="password" class="form-control" name="password" placeholder="Password">
</div>
<div class="form-group">
<label>Confirmasi Password</label>
<input type="password" class="form-control" name="ulangi_password" placeholder="Confirmasi Password">
</div>
<button class="btn btn-block btn-danger" type="submit">Daftar</button>
<button class="btn btn-block btn-danger" type="reset">Batal</button>
<tbody>
  <table>
    <div class="daftar akun">

      <tr><td colspan="2" align="center">Sudah Punya akun ? <a href="login.php" class="daftar akun"><b>Login</b></a></td></tr>
    </div>
  </tbody>
  </table>
  </form>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
